<?php
$host = 'localhost';
$db_name = 'kgpathwebsite';
$username = 'kgpathadmin';  
$password = 'Kgpath@2025@';

try {
    $pdo = new PDO("mysql:host={$host};dbname={$db_name}", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}
?>